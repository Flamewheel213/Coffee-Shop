//Project Name:CoffeeShop
//File Name:Coffeeshop
//Creation Date: May 6, 2017
//Modification Date: May 14, 2017
//Description:This program was made to simulate a coffee shop with basic shapes and no animation
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using CoffeeShop.Classes;

namespace CoffeeShop
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class CoffeeShop : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager Graphics;
        SpriteBatch SpriteBatch;

        //Width = 800
        //Height = 480

        //Screen Parameters
        int Screenwidth;
        int Screenheight;

        //Lists holding Information about cashiers and customers
        List<Customer> CustomerList = new List<Customer>();
        List<Customer> QueueList = new List<Customer>();

        int[] Cashiers = new int[4];
        int Counter { get; set; }
       
        //Sprites
        Texture2D FoodTexture;
        Texture2D CoffeeTexture;
        Texture2D BothTexture;
        Texture2D CustomerTexture;

        //Fonts needed
        SpriteFont TimerFont;

        //Shapes to be used within the map with set positions
        Texture2D CounterTexture;
        Rectangle CounterBounds;
        Rectangle CounterBounds2;

        Texture2D OutsideTexture;
        Rectangle OutsideBounds;
        Rectangle OutsideBounds2;

        Texture2D DoorTexture;
        Rectangle DoorBounds;
        Rectangle DoorBounds2;
        Rectangle DoorBounds3;
        Rectangle DoorBounds4;

        //Position to summon customers
        Rectangle CustomerBounds;

        //Sprite with set positions
        Texture2D[] CashierTexture = new Texture2D[4];
        Vector2[] CashierPosition = new Vector2[4];
        Rectangle[] CashierBounds = new Rectangle[4];

        KeyboardState OldState;

        double TotalCoffeeShopTimer;
        double TotalSpawnTimer;
        Boolean TimerRunning;

        public CoffeeShop()
        {
            Graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            TotalCoffeeShopTimer = 300;
            TotalSpawnTimer =  0;
            TimerRunning = false;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            //Checks the screen Height and Width of the screen
            Screenwidth = GraphicsDevice.Viewport.Width;
            Screenheight = GraphicsDevice.Viewport.Height;

            base.Initialize();

            OldState = Keyboard.GetState();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            SpriteBatch = new SpriteBatch(GraphicsDevice);          

            //Loads Sprites
            LoadResources();

            //Places the location of the sprites but with no variables except the location
            DesignFeatures();

            //Postion of stats goes here
        }
        /// <summary>
        /// Pre: Needs to be loaded
        /// Post: Loads Sprites into functions
        /// Desc: By taking the sprites from Content, it then moves them into these functions
        /// </summary>
        private void LoadResources()
        {
            int Loop = 4;
            string image = "Resources\\Coffee Sprite";
            CoffeeTexture = Content.Load<Texture2D>(image);

            string image2 = "Resources\\Food Sprite";
            FoodTexture = Content.Load<Texture2D>(image2);

            string image3 = "Resources\\Both Sprite";
            BothTexture = Content.Load<Texture2D>(image3);
        
            for(int i = 0; i < Loop; i++)
            {
                string image4 = "Resources\\Cashier Sprite";
                CashierTexture[i] = Content.Load<Texture2D>(image4);
            }

            string image5 = "Resources\\Door";
            DoorTexture = Content.Load<Texture2D>(image5);

            string image6 = "Resources\\RealCounter";
            CounterTexture = Content.Load<Texture2D>(image6);

            string image7 = "Resources\\Outside";
            OutsideTexture = Content.Load<Texture2D>(image7);

            string image8 = "Resources\\TimerFont";
            TimerFont = Content.Load<SpriteFont>(image8);
        }
        /// <summary>
        /// Pre:Needs to be loaded
        /// Post: Loads Locations into functions
        /// Desc:Loads specfic locations and by puting them into functions, it allows access to the sprites
        /// </summary>
        private void DesignFeatures()
        {
            //Loads the locations for the pictures to be in
            CounterBounds = new Rectangle(0, 60, CounterTexture.Width, CounterTexture.Height);
            CounterBounds2 = new Rectangle(400, 60, CounterTexture.Width, CounterTexture.Height);

            OutsideBounds = new Rectangle(400, 440, OutsideTexture.Width, OutsideTexture.Height);
            OutsideBounds2 = new Rectangle(000, 440, OutsideTexture.Width, OutsideTexture.Height);

            DoorBounds = new Rectangle(600, 420, DoorTexture.Width, DoorTexture.Height);
            DoorBounds2 = new Rectangle(400, 420, DoorTexture.Width, DoorTexture.Height);
            DoorBounds3 = new Rectangle(-200, 420, DoorTexture.Width, DoorTexture.Height);
            DoorBounds4 = new Rectangle(160, 420, DoorTexture.Width, DoorTexture.Height);

            CustomerBounds = new Rectangle(600, 450, 30, 30);
 

            //loads the locations of the cashiers
            for (int i = 0; i < 4; i++)
            {
                CashierBounds[i] = new Rectangle(100 + (i * 200), 25, CashierTexture[i].Width, CashierTexture[i].Height);
            }
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            KeyboardState newState = Keyboard.GetState();
            if (newState.IsKeyDown(Keys.Space))
            {
                // Start my program
                StartTimer();
            }
            if (!TimerRunning)
            {
                // My program is finished.
                return;
            }

            if (TotalSpawnTimer <=0 )
            {
                AddCustomer();
                TotalSpawnTimer = Constants.SpawnTimer;
            }

            UpdateTimers(gameTime);

            MoveCustomers();

            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            base.Update(gameTime);
        }
        public void MoveCustomers() 
        {
            int maxPosition = 100;
            foreach(var customer in CustomerList)
            {
                if (customer.PositionX == maxPosition && !customer.IsInQueue)
                {
                    //See if I can move to the queue Move to the queue
                    if (QueueList.Count >= 20)
                    {
                        customer.IsWaiting = true;
                        maxPosition += 40;
                    }
                    else 
                    {
                        QueueList.Add(customer);
                        customer.IsWaiting = false;
                        customer.IsInQueue = true;
                    }
                }
                if (!customer.IsWaiting && !customer.IsInQueue)
                {
                    customer.PositionX -= 1;
                }
             }
            int queueMaxPositionX = 700;
            int queueMaxPositionY = 250;
            int index = 0;
            foreach (var customer in QueueList) 
            {
                index += 1;
                if (customer.PositionX <= queueMaxPositionX)
                {
                    customer.PositionX += 1;
                }
                else { queueMaxPositionX -= 40; }
                if (customer.PositionY >= queueMaxPositionY) customer.PositionY -= 1;
                if (index == 10) 
                {
                     queueMaxPositionX = 700;
                     queueMaxPositionY = 300;
                }

            }
        }

        public void AddCustomer()
        {
            Customer myCustomer = new Customer();
            myCustomer.IsSpawned = true;
            myCustomer.Number = Counter + 1;
            Counter += 1;
            CustomerList.Add(myCustomer);
        }


        private void StartTimer()
        {
            TotalCoffeeShopTimer = Constants.CoffeeShopTimer;
            TimerRunning = true;
        }

        private void UpdateTimers(GameTime gameTime)
        {
            double elapsed = (double)gameTime.ElapsedGameTime.TotalSeconds;
            TotalCoffeeShopTimer -= elapsed;
            TotalSpawnTimer -= elapsed;
            if (TotalCoffeeShopTimer < 0)
            {
                TimerRunning = false;
                return;
            }
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            SpriteBatch.Begin();
            
            // Draws the needed background Sprites
            SpriteBatch.Draw(CounterTexture, CounterBounds, Color.White);
            SpriteBatch.Draw(CounterTexture, CounterBounds2, Color.White);

            SpriteBatch.Draw(DoorTexture, DoorBounds, Color.White);
            SpriteBatch.Draw(DoorTexture, DoorBounds2, Color.White);
            SpriteBatch.Draw(DoorTexture, DoorBounds3, Color.White);
            SpriteBatch.Draw(DoorTexture, DoorBounds4, Color.White);
            SpriteBatch.Draw(OutsideTexture, OutsideBounds, Color.White);
            SpriteBatch.Draw(OutsideTexture, OutsideBounds2, Color.White);

            foreach(var customer in CustomerList)
            {
                var bounds = new Rectangle(customer.PositionX, customer.PositionY, 30, 30);
                switch(customer.SpawnType)
                {
                    case(1):
                        CustomerTexture = CoffeeTexture;
                        break;
                    case(2):
                        CustomerTexture = FoodTexture;
                        break;
                    case(3):
                        CustomerTexture = BothTexture;
                        break;
                    default:
                        break;
                }

                SpriteBatch.Draw(CustomerTexture, bounds, Color.White);
                SpriteBatch.DrawString(TimerFont, customer.Number.ToString(), new Vector2(customer.PositionX, customer.PositionY), Color.White);
            }


            for (int i = 0; i < 4; i++)
            {
                SpriteBatch.Draw(CashierTexture[i], CashierBounds[i], Color.White);
            }

            // Draws the text for the program

            SpriteBatch.DrawString(TimerFont,"Simulation Time:" + Math.Truncate(TotalCoffeeShopTimer).ToString(), new Vector2(0, 60), Color.White);

            for (int i = 0; i < 4; i++)
            {
                SpriteBatch.DrawString(TimerFont, "Cashier " + (i + 1).ToString(), new Vector2(65 + (i * 200), 0), Color.White);
            }
            if (!TimerRunning)
            {
                SpriteBatch.DrawString(TimerFont, "Press <Space> to start the CoffeeShop Simulation", new Vector2(140, 200), Color.White);
            }
            

            SpriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
