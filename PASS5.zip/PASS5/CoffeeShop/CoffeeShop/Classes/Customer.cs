﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoffeeShop.Classes
{
    public class Customer
    {
        public bool IsSpawned;
        public int Number { get; set; }
        public int PositionX { get; set; }
        public int PositionY { get; set; }
        public int SpawnType { get; set; }
        public int CustomerWaitTime { get; set; }
        public bool IsWaiting { get; set; }
        public bool IsInQueue { get; set; }

        public Customer() 
        {
            PositionX = 700; //780
            PositionY = 450;
            Random rng = new Random();
            SpawnType = rng.Next(1, 4);
            IsWaiting = false;
            IsInQueue = false;
        }
        
    }
}
