﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoffeeShop.Classes
{
    class Stats
    {
        public int minWait { get; set; }
        public int maxWait { get; set; }
        public int avgWait { get; set; }
        public int peopleServed { get; set; }

    }
}
